# Termux Developer Edition

Termux Developer Edition is a source-tree customization that adds an optional,
interactive developer environment setup helper. The Android app remains a
terminal emulator; compilers, interpreters and SDKs are installed as Termux
packages after the app starts. This keeps the APK smaller and lets the package
manager select binaries for the device's supported architecture.

## Recommended setup

1. Install Termux from one supported source (F-Droid or the official GitHub
   releases). Do not mix APK sources because their signing keys differ.
2. Open Termux and update its package metadata:

   ```sh
   pkg update && pkg upgrade
   ```

3. Copy `scripts/termux-developer-setup.sh` into Termux, then run:

   ```sh
   bash termux-developer-setup.sh
   ```

4. Choose option `1` for the recommended core tools. Select optional language
   toolchains only when needed. The script detects the device architecture via
   `uname -m`, checks package availability in the configured repository, and
   asks before installing.

## Included setup choices

- **Recommended core:** Git, curl, wget, OpenSSH, nano, Vim, Python/pip,
  Node.js, Clang, Make, CMake and pkg-config (only packages available in the
  current repository are offered).
- **On demand:** OpenJDK, Go, Rust, Ruby, PHP/Composer, Perl, Lua/LuaRocks,
  Deno, Dart, Swift, GHC/Haskell, Zig and C#/.NET SDK where packages
  are available in the configured repository. .NET checks supported SDK package
  versions before selecting one.
- Large or architecture-limited toolchains are not installed by the default
  core option.

## Architecture and compatibility

No ABI is hard-coded. The script reports `uname -m` for diagnostics and relies
on Termux's configured repositories and package metadata to supply compatible
packages. Package names and availability can change over time or differ by
repository mirror. Missing packages are skipped rather than assumed to exist.

The helper does not bundle language runtimes into the APK, alter the Android
bootstrap, or guarantee that every optional language is available on every
architecture. For package-level issues, consult the Termux packages project:
https://github.com/termux/termux-packages

## English interface

All added helper prompts and documentation are in English. The existing app
localization resources are not modified.
