#!/data/data/com.termux/files/usr/bin/bash
# Termux Developer Edition: lightweight core setup + on-demand language toolchains.
# Packages are fetched from the configured Termux repositories for this device.

set -u

if [ -z "${PREFIX:-}" ] || [ ! -d "$PREFIX" ] || ! command -v pkg >/dev/null 2>&1; then
    echo "Error: run this script inside the Termux app."
    exit 1
fi

ARCH="$(uname -m 2>/dev/null || echo unknown)"
case "$ARCH" in
    aarch64|arm64) ARCH_LABEL="ARM64 (aarch64)" ;;
    armv7l|armv8l) ARCH_LABEL="ARM 32-bit ($ARCH)" ;;
    x86_64|i686|i386) ARCH_LABEL="x86 ($ARCH)" ;;
    *) ARCH_LABEL="$ARCH" ;;
esac

if ! command -v apt-cache >/dev/null 2>&1; then
    echo "Error: apt-cache is unavailable. Update Termux and try again."
    exit 1
fi

has_package() {
    apt-cache show "$1" 2>/dev/null | grep -q '^Package:'
}

filter_packages() {
    local p
    AVAILABLE=()
    for p in "$@"; do
        if has_package "$p"; then
            AVAILABLE+=("$p")
        else
            printf '  - Skipping unavailable package: %s\n' "$p"
        fi
    done
}

install_group() {
    local label="$1"
    shift
    local requested=("$@")
    local packages=()
    filter_packages "${requested[@]}"
    packages=("${AVAILABLE[@]}")
    if [ "${#packages[@]}" -eq 0 ]; then
        echo "No compatible packages found for: $label"
        return 1
    fi
    printf '\n%s\n' "$label"
    printf 'Packages: %s\n' "${packages[*]}"
    printf 'Install now? [y/N] '
    local answer
    IFS= read -r answer || return 1
    case "$answer" in
        y|Y|yes|YES|Yes) pkg install -y "${packages[@]}" ;;
        *) echo "Skipped: $label" ;;
    esac
}

show_menu() {
    cat <<'MENU'

====================================================
             TERMUX DEVELOPER EDITION
====================================================
  1. Install recommended developer core
     Git, curl, wget, OpenSSH, editors, Python,
     Node.js, Clang/C/C++, Make, CMake and pkg-config

  2. Python + pip
  3. Java (OpenJDK)
  4. C / C++ (Clang, Make, CMake)
  5. JavaScript / TypeScript (Node.js)
  6. Go
  7. Rust
  8. Ruby
  9. PHP + Composer
 10. Perl
 11. Lua + LuaRocks
 12. Deno
 13. Dart
 14. Swift (large; if available)
 15. Haskell / GHC (large; if available)
 16. Zig
 17. C# / .NET SDK (if available)

 18. Install all available standard toolchains
 19. Exit

You can choose multiple numbers separated by spaces or commas.
Large or less common toolchains are never installed by option 1.
MENU
}

CORE=(git curl wget openssh nano vim python python-pip nodejs-lts clang make cmake pkg-config)

packages_for() {
    case "$1" in
        2) printf '%s\n' python python-pip ;;
        3) printf '%s\n' openjdk-21 ;;
        4) printf '%s\n' clang make cmake pkg-config ;;
        5) printf '%s\n' nodejs-lts ;;
        6) printf '%s\n' golang ;;
        7) printf '%s\n' rust ;;
        8) printf '%s\n' ruby ;;
        9) printf '%s\n' php composer ;;
        10) printf '%s\n' perl ;;
        11) printf '%s\n' lua54 luarocks ;;
        12) printf '%s\n' deno ;;
        13) printf '%s\n' dart ;;
        14) printf '%s\n' swift ;;
        15) printf '%s\n' ghc ;;
        16) printf '%s\n' zig ;;
        17)
            # Prefer the newest SDK package present in the configured repository.
            for candidate in dotnet-sdk-10.0 dotnet-sdk-9.0 dotnet-sdk-8.0; do
                if has_package "$candidate"; then
                    printf '%s\n' "$candidate"
                    return 0
                fi
            done
            return 0
            ;;
        *) return 1 ;;
    esac
}

if ! pkg update; then
    echo "Repository update failed. Check your network or change the Termux mirror, then retry."
    exit 1
fi

printf '\nDetected device architecture: %s\n' "$ARCH_LABEL"
show_menu
printf 'Select options: '
IFS= read -r choices || exit 1
choices=${choices//,/ }

selected=()
for choice in $choices; do
    case "$choice" in
        1) selected+=("${CORE[@]}") ;;
        2|3|4|5|6|7|8|9|10|11|12|13|14)
            while IFS= read -r package; do
                [ -n "$package" ] && selected+=("$package")
            done < <(packages_for "$choice")
            ;;
        16)
            selected+=(python python-pip openjdk-21 clang make cmake pkg-config nodejs-lts golang rust ruby php composer perl lua54 luarocks deno dart swift ghc)
            ;;
        17) echo "Cancelled."; exit 0 ;;
        *) printf 'Ignoring invalid option: %s\n' "$choice" ;;
    esac
done

if [ "${#selected[@]}" -eq 0 ]; then
    echo "Nothing selected. No packages were installed."
    exit 0
fi

# Deduplicate while preserving selection order.
unique=()
for package in "${selected[@]}"; do
    found=0
    for existing in "${unique[@]}"; do
        [ "$existing" = "$package" ] && found=1 && break
    done
    [ "$found" -eq 0 ] && unique+=("$package")
done

filter_packages "${unique[@]}"
if [ "${#AVAILABLE[@]}" -eq 0 ]; then
    echo "No selected packages are available for this device/repository."
    exit 1
fi

printf '\nReady to install on %s:\n%s\n' "$ARCH_LABEL" "${AVAILABLE[*]}"
printf 'Continue? [y/N] '
IFS= read -r confirm || exit 1
case "$confirm" in
    y|Y|yes|YES|Yes) pkg install -y "${AVAILABLE[@]}" ;;
    *) echo "Cancelled. No packages were installed."; exit 0 ;;
esac

status=$?
if [ "$status" -ne 0 ]; then
    echo "Some packages could not be installed. Review the pkg output above."
    exit "$status"
fi

echo
 echo "Developer tools setup finished."
echo "Examples: python --version | clang --version | node --version | git --version"
echo "Optional toolchains can be installed later by running this script again."
